
<?php
require_once('cabecalho.php');
require_once('conexao.php');
?>

<h1>Novo Professor</h1>

<form method="post">

    <div class="mb-3">
        <label class="form-label">Informe o nome</label>
        <input type="text" name="nome" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label class="form-label">Informe o email</label>
        <input type="text" name="email" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label class="form-label">Informe a especialidade</label>
        <input type="text" name="especialidade" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>

</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $especialidade = $_POST['especialidade'];

    try {
        $stmt = $pdo->prepare('INSERT INTO professores (nome, email, especialidade) VALUES (?, ?, ?);');

        if ($stmt->execute([$nome, $email, $especialidade])) {
            echo "<p>Cadastro realizado!</p>";
        } else {
            echo "<p>Erro ao cadastrar! Tente novamente</p>";
        }

    } catch (Exception $e) {
        echo "Erro: " . $e->getMessage();
    }
}
?>

<?php require_once('rodape.php'); ?>
